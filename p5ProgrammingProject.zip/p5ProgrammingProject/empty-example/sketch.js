function setup() {
  createCanvas(500, 500);
}
function draw() {
  background(51);
  //candle wick
  stroke(128, 128, 128);
  line(250, 275, 250, 300);
  //candle
  stroke(255);
  strokeWeight(3);
  fill(255, 255, 240);
  rect(235, 300, 30, 90);
  //candle shadow
  stroke(255);
  strokeWeight(3);
  fill('#222222');
  ellipse(250, 390, 50, 5);
  //candle flame
  let a = map(mouseY, 0, height, 300, 40);
  stroke(170, 30, 30);
  fill(255, 215, 0);
  ellipse(250, 270, a, a);
                }

  